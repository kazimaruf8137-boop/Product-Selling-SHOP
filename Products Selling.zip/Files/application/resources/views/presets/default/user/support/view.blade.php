@extends($activeTemplate.'layouts.'.$layout)

@section('content')
<div class="{{auth()->user() ? 'col-xl-9 col-lg-8': 'col-lg-12'}}">
    <div class="dashboard-body account-form {{auth()->user() ? '': 'container mt-5'}}">
        <div class="dashboard-body__bar">
            <span class="dashboard-body__bar-icon"><i class="las la-bars"></i></span>
        </div>
        <div class="row justify-content-center">
            <div class="d-flex flex-wrap justify-content-between align-items-center mb-1">
                <h5 class="mt-0">
                    @php echo $myTicket->statusBadge; @endphp
                    [@lang('Ticket')#{{ $myTicket->ticket }}] {{ $myTicket->subject }}
                </h5>
                @if($myTicket->status != 3 && $myTicket->user)
                <button class="btn btn-danger close-button btn--sm confirmationBtn" type="button" data-question="@lang('Are you sure to close this ticket?')" data-action="{{ route('ticket.close', $myTicket->id) }}"><i class="fa fa-lg fa-times-circle"></i>
                </button>
                @endif
            </div>

            @if($myTicket->status != 4)
                <form method="post" action="{{ route('ticket.reply', $myTicket->id) }}" enctype="multipart/form-data">
                    @csrf
                    <div class="row justify-content-between">
                        <div class="col-md-12">
                            <div class="form-group">
                                <textarea name="message" class="form-control form--control" rows="4">{{ old('message') }}</textarea>
                            </div>
                        </div>
                    </div>
                    <div class="text-end">
                        <a href="javascript:void(0)" class="btn btn--base mt-1 btn--sm addFile"><i class="fa fa-plus"></i> @lang('Add New')</a>
                    </div>
                    <div class="form-group">
                        <label class="form-label">@lang('Attachments')</label>
                        <input type="file" name="attachments[]" class="form-control form--control"/>
                        <div id="fileUploadsContainer"></div>
                        <p class="my-2 ticket-attachments-message text-muted">
                            @lang('Allowed File Extensions'): .@lang('jpg'), .@lang('jpeg'), .@lang('png'), .@lang('pdf'), .@lang('doc'), .@lang('docx')
                        </p>
                    </div>
                    <button type="submit" class="btn btn--base"> <i class="fa fa-reply"></i> @lang('Reply')</button>
                </form>
            @endif


            <div class="mt-4 admin-user-comment-wrapper">
                @foreach($messages as $message)
                    @if($message->admin_id == 0)
                        <div class="row border  border-radius-3 my-3 py-3 mx-2">
                            <div class="col-md-9">
                                <p class="text-muted fw-bold my-3">
                                    <h5>@ {{ $message->ticket->name }}</h5>
                                    @lang('Posted on') {{ $message->created_at->format('l, dS F Y @ H:i') }}</p>
                                <p>{{$message->message}}</p>
                                @if($message->attachments->count() > 0)
                                    <div class="mt-2">
                                        @foreach($message->attachments as $k=> $image)
                                            <a href="{{route('ticket.download',encrypt($image->id))}}" class="me-3"><i class="fa fa-file"></i>  @lang('Attachment') {{++$k}} </a>
                                        @endforeach
                                    </div>
                                @endif
                            </div>
                        </div>
                    @else
                        <div class="row border  border-radius-3 my-3 py-3 mx-2">
                            <div class="col-md-9">
                                <p class="text-muted fw-bold my-3">
                                    <h5>@ {{ $message->admin->name }}</h5>
                                    @lang('Posted on') {{ $message->created_at->format('l, dS F Y @ H:i') }}</p>
                                <p>{{$message->message}}</p>
                                @if($message->attachments->count() > 0)
                                    <div class="mt-2">
                                        @foreach($message->attachments as $k=> $image)
                                            <a href="{{route('ticket.download',encrypt($image->id))}}" class="me-3"><i class="fa fa-file"></i>  @lang('Attachment') {{++$k}} </a>
                                        @endforeach
                                    </div>
                                @endif
                            </div>
                        </div>
                    @endif
                @endforeach
            </div>
        </div>
    </div>
</div>

<x-confirmation-modal></x-confirmation-modal>
</section>
@endsection
@push('style')
    <style>
        .input-group-text:focus{
            box-shadow: none !important;
        }
    </style>
@endpush
@push('script')
    <script>
        (function ($) {
            "use strict";
            var fileAdded = 0;
            $('.addFile').on('click',function(){
                if (fileAdded >= 4) {
                    notify('error','You\'ve added maximum number of file');
                    return false;
                }
                fileAdded++;
                $("#fileUploadsContainer").append(`
                    <div class="input-group my-3">
                        <input type="file" name="attachments[]" class="form-control form--control" required />
                        <button class="input-group-text btn-danger remove-btn"><i class="las la-times"></i></button>
                    </div>
                `)
            });
            $(document).on('click','.remove-btn',function(){
                fileAdded--;
                $(this).closest('.input-group').remove();
            });
        })(jQuery);

    </script>
@endpush
